This folder contains the hyphenation tables for the DARIAH DKPro Wrapper. These tables originate from the TeX User Group (http://tug.org/tex-hyphen/#introduction). They were downloaded from this website: http://tug.org/svn/texhyphen/trunk/hyph-utf8/tex/generic/hyph-utf8/patterns/tex/

For copyright notices, see the individual hyphenation table files.

